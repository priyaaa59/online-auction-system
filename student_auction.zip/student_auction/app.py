from flask import Flask, render_template, request, redirect, url_for, session, flash, send_from_directory
from flask_pymongo import PyMongo
from werkzeug.utils import secure_filename
from datetime import datetime, timedelta
import os

app = Flask(__name__)
app.secret_key = "secret"
app.config["MONGO_URI"] = "mongodb://localhost:27017/auction"
app.config["UPLOAD_FOLDER"] = "static/uploads"
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}

mongo = PyMongo(app)

# Helpers
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route("/")
def home():
    return render_template("home.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        user = {
            "username": request.form["username"],
            "password": request.form["password"],
            "email": request.form["mailid"],
            "location": request.form["location"],
            "mobile": request.form["mobile"]
        }
        mongo.db.users.insert_one(user)
        flash("Registration Successful")
        return redirect(url_for("login"))
    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        user = mongo.db.users.find_one({"username": request.form["username"], "password": request.form["password"]})
        if user:
            session["username"] = user["username"]
            return redirect(url_for("dashboard"))
        flash("Invalid credentials")
    return render_template("login.html")

@app.route("/dashboard")
def dashboard():
    if "username" not in session:
        return redirect(url_for("login"))
    return render_template("dashboard.html", username=session["username"])

@app.route("/upload", methods=["GET", "POST"])
def upload_item():
    if "username" not in session:
        return redirect(url_for("login"))
    if request.method == "POST":
        file = request.files["image"]
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config["UPLOAD_FOLDER"], filename)
            file.save(filepath)
            item = {
                "title": request.form["title"],
                "description": request.form["description"],
                "base_price": float(request.form["base_price"]),
                "end_time": datetime.utcnow() + timedelta(minutes=int(request.form["duration"])),
                "image": filename,
                "username": session["username"],
                "bids": []
            }
            mongo.db.items.insert_one(item)
            flash("Item uploaded for auction")
            return redirect(url_for("auction_list"))
    return render_template("upload_item.html")

@app.route("/auctions")
def auction_list():
    items = list(mongo.db.items.find({"end_time": {"$gt": datetime.utcnow()}}))
    return render_template("auction_list.html", items=items)

@app.route("/auction/<item_id>", methods=["GET", "POST"])
def auction_detail(item_id):
    from bson.objectid import ObjectId
    item = mongo.db.items.find_one({"_id": ObjectId(item_id)})
    if request.method == "POST" and "username" in session:
        bid = {
            "user": session["username"],
            "amount": float(request.form["bid_amount"]),
            "time": datetime.utcnow()
        }
        mongo.db.items.update_one({"_id": ObjectId(item_id)}, {"$push": {"bids": bid}})
        flash("Bid placed successfully")
        return redirect(url_for("auction_detail", item_id=item_id))
    return render_template("auction_detail.html", item=item)

@app.route("/admin_login", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        if request.form["username"] == "admin" and request.form["password"] == "admin":
            session["admin"] = True
            return redirect(url_for("admin_dashboard"))
        flash("Invalid admin credentials")
    return render_template("admin_login.html")

@app.route("/admin_dashboard")
def admin_dashboard():
    if "admin" not in session:
        return redirect(url_for("admin_login"))
    users = list(mongo.db.users.find())
    items = list(mongo.db.items.find())
    return render_template("admin_dashboard.html", users=users, items=items)

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("home"))

if __name__ == "__main__":
    app.run(debug=True)
